from .base import OAuth2Login
from .linkedin import LinkedInLogin


"""
Con esto se exponen las clases del paquete proveedor.
"""